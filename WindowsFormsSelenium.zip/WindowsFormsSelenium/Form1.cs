﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenQA.Selenium;


namespace WindowsFormsSelenium
{
    public partial class Form1 : Form
    {
        IWebDriver ChromeBrowser;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            textBox1.Size = this.Size;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ChromeBrowser = new OpenQA.Selenium.Chrome.ChromeDriver();

            ChromeBrowser.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            //ChromeBrowser.Manage().Timeouts().ImplicitWait.Add(TimeSpan.FromSeconds(20));
            //ChromeBrowser.Manage().Window.Maximize();

            // 1.	Открыть страницу google.com (или любой другой поисковик на ваш выбор)
            //      и ввести в строке поиска habrahabr:
            ChromeBrowser.Navigate().GoToUrl(@"https://www.google.com/");

            // 2.	После отображения результатов поиска, открыть сайт habrahabr.ru кликом на ссылку
            //      (доп плюсом будет если вы выберете не первый результат поиска, а именно выберете
            //      тот, который с доменным именем habrahabr.ru):
            IWebElement s = ChromeBrowser.FindElement(By.Name("q"));
            s.SendKeys("habrahabr" + OpenQA.Selenium.Keys.Enter);

            try
            {
                ChromeBrowser.FindElement(By.XPath("//a[@href='https://habrahabr.ru']")).Click();
            }
            catch
            {
                //ChromeBrowser.FindElement(By.PartialLinkText("habrahabr.ru")).Click();
                ChromeBrowser.FindElement(By.XPath("//a[contains(@href, 'https://habrahabr.ru')]")).Click();
            }
           
            //Thread.Sleep(3000);

            // 3.	Перейти в раздел "Песочница" кликом на ссылку в меню:
            IWebElement SearchForm;
            SearchForm = ChromeBrowser.FindElement(By.CssSelector(".footer-grid_menu"));//Находим меню чтобы исключить ссылки в других местах
            SearchForm.FindElement(By.LinkText("Песочница")).Click();

            // 4.	Открыть 2-ю страницу раздела "Песочница" кликом на цифру "2" в пагинации:
            SearchForm = ChromeBrowser.FindElement(By.Id("nav-pagess"));
            SearchForm.FindElement(By.LinkText("2")).Click();

            // 5.	Запомнить тайтл первого поста на странице:
            string title = ChromeBrowser.FindElement(By.CssSelector(".post__title_link")).Text;
            textBox1.Text = "Поисковой запрос:" + Environment.NewLine + title + Environment.NewLine;

            // 6.	Открыть google.com и произвести поиск по значению из шага 5:
            ChromeBrowser.Navigate().GoToUrl(@"https://www.google.com/");
            ChromeBrowser.FindElement(By.Name("q")).SendKeys(title + OpenQA.Selenium.Keys.Enter); ;

            // 7.	Проверить, что результаты поиска соответствуют искомому значению:
            IList<IWebElement> elementName = ChromeBrowser.FindElements(By.TagName("em"));
            textBox1.Text += Environment.NewLine + "Найдено совпадений " + elementName.Count.ToString() + ":" + Environment.NewLine;
            foreach (IWebElement i in elementName)
            {
                textBox1.Text += (i.Text) + Environment.NewLine;
            }

            this.Show();

        }

        
    }
}
